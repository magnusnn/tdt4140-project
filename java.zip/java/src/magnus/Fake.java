package magnus;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;




public class Fake {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		

		   DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
		   DateFormat dateFormat2 = new SimpleDateFormat("dd-MM-yyyy");
		   //get current date time with Date()
		   Date date = new Date();
		   System.out.println(dateFormat.format(date));
	 
		   //get current date time with Calendar()
		   Calendar cal = Calendar.getInstance();
		   System.out.println(dateFormat.format(cal.getTime()));
		   
		   
		   System.out.println(dateFormat2.format(date));
	 
	  }

}
