package anniken;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.JScrollPane;
import anniken.Event;
import per.Calendar;
import per.Group;

import javax.swing.SwingConstants;

public class MainFrame extends JFrame {
	
	private JPanel contentPane;
	private Calendar calendar;
	private ArrayList<Event> events;
	private int topHour;
	private ArrayList<ArrayList<JPanel>> eventPanels; //a list of eventPanels for each day of the week, starting with Sunday
	private JPanel mondayPanel;
	private JPanel tuesdayPanel;
	private JPanel wednesdayPanel;
	private JPanel thursdayPanel;
	private JPanel fridayPanel;
	private JPanel saturdayPanel;
	private JPanel sundayPanel;
	private ArrayList<JLabel> hourLabels;
	private ArrayList<JPanel> days;
	private java.util.Calendar cal;
	private int weekNumber;
	private JLabel weeknr;
	private ArrayList<JLabel> dateLabels;
	
	public Calendar getCalendar() {
		return calendar;
	}
	
	public void incrementTopHour() {
		if (topHour < 16)
			topHour++;
		repaintTimes();
		addAllEvents();
	}
	
	public void decrementTopHour() {
		if (topHour > 0)
			topHour--;
		repaintTimes();
		addAllEvents();
	}
	
	public void nextWeek() {
		cal.setTime(new Date(cal.getTimeInMillis() + 604800000));
		changeWeek();
	}
	
	public void previousWeek() {
		cal.setTime(new Date(cal.getTimeInMillis() - 604800000));
		changeWeek();
	}
	
	public void changeWeek() {
		weekNumber = cal.get(java.util.Calendar.WEEK_OF_YEAR);
		weeknr.setText(Integer.toString(weekNumber));
		paintDates();
		addAllEvents();
	}
	
	public void paintDates() {
		int dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK) - 2;
		if (dayOfWeek == -1)
			dayOfWeek = 6;
		cal.setTime(new Date(cal.getTimeInMillis() - 86400000 * dayOfWeek));
		for (int i = 0; i < dateLabels.size(); i++) {
			String dayZero = "";
			if (cal.get(java.util.Calendar.DATE) < 10)
				dayZero = "0";
			String monthZero = "";
			if (cal.get(java.util.Calendar.MONTH) < 9)
				monthZero = "0";
			dateLabels.get(i).setText(dayZero + Integer.toString(cal.get(java.util.Calendar.DATE)) + "-" + monthZero + Integer.toString(cal.get(java.util.Calendar.MONTH) + 1) + "-" + Integer.toString(cal.get(java.util.Calendar.YEAR)));
			cal.setTime(new Date(cal.getTimeInMillis() + 86400000));
		}
		cal.setTime(new Date(cal.getTimeInMillis() - 86400000 * (7 - dayOfWeek)));
	}
	
	public void repaintTimes() {
		for (int i = 0; i < 8; i++) {
			String zero = "";
			if (topHour + i < 10)
				zero = "0";
			hourLabels.get(i).setText(zero + (topHour + i) + ":00");
		}
	}
	
	public void addAllEvents() {
		eventPanels = new ArrayList<ArrayList<JPanel>>();
		for (int i = 0; i < 7; i++) {
			eventPanels.add(new ArrayList<JPanel>());
		}
		Collections.sort(events);
		Collections.reverse(events);
		mondayPanel.removeAll();
		tuesdayPanel.removeAll();
		wednesdayPanel.removeAll();
		thursdayPanel.removeAll();
		fridayPanel.removeAll();
		saturdayPanel.removeAll();
		sundayPanel.removeAll();
		for (int i = 0; i < events.size(); i++) {
			addEvent(events.get(i));
		}
		for (int i = 0; i < eventPanels.size(); i++) {
			for (int j = 0; j < eventPanels.get(i).size(); j++) {
				if (eventPanels.get(i).get(j).getWidth() == 61) {
					if (j == 0 || eventPanels.get(i).get(j-1).getY() > eventPanels.get(i).get(j).getY() + eventPanels.get(i).get(j).getHeight()) {
						if (j == eventPanels.get(i).size() - 1 || eventPanels.get(i).get(j+1).getY() + eventPanels.get(i).get(j+1).getHeight() < eventPanels.get(i).get(j).getY())
							eventPanels.get(i).get(j).setSize(121, eventPanels.get(i).get(j).getHeight());
					}
				}
			}
		}
		repaint();
		this.getRootPane().revalidate();
	}
	
	public void addEvent(Event event) {
		Date date = null;
		try {
			date = new SimpleDateFormat("dd-MM-yyyy").parse(event.getDate());
		}
		catch (Exception e) {
			return;
		}
		java.util.Calendar c = java.util.Calendar.getInstance();
		c.setTime(date);
		int eventWeek = c.get(java.util.Calendar.WEEK_OF_YEAR);
		if (eventWeek != weekNumber)
			return;
		int weekDay = c.get(java.util.Calendar.DAY_OF_WEEK); // 1 is Sunday, 7 is Saturday
		weekDay = weekDay % 7;
		if (weekDay == 0)
			weekDay = 7;
		int hoursStart = Integer.parseInt(event.getStartTime().substring(0, 2));
		int minutesStart = Integer.parseInt(event.getStartTime().substring(2));
		int heightStart = (hoursStart - topHour) * 70 + minutesStart * 7/6;
		int height = event.getDuration() * 7/6;
		if (heightStart + height > 1680) {
			int newWeekDay = weekDay + 1;
			if (newWeekDay > 7)
				newWeekDay -= 7;
			addEventPanel(event, 0, heightStart + height - 1680, newWeekDay);
			height = 1680 - heightStart;
		}
		addEventPanel(event, heightStart, height, weekDay);
	}
	
	public void addEventPanel(final Event event, int heightStart, int height, int weekDay) {
		int widthStart = -1;
		if (eventPanels.get(weekDay - 1).size() == 0)
			widthStart = 0;
		else if (eventPanels.get(weekDay - 1).get(eventPanels.get(weekDay - 1).size() - 1).getY() > heightStart + height)
			widthStart = 0;
		else if (eventPanels.get(weekDay - 1).get(eventPanels.get(weekDay - 1).size() - 1).getX() == 60 && (eventPanels.get(weekDay - 1).size() == 1 || eventPanels.get(weekDay - 1).get(eventPanels.get(weekDay - 1).size() - 2).getY() > heightStart + height))
			widthStart = 0;
		else if (eventPanels.get(weekDay - 1).get(eventPanels.get(weekDay - 1).size() - 1).getX() == 0 && (eventPanels.get(weekDay - 1).size() == 1 || eventPanels.get(weekDay - 1).get(eventPanels.get(weekDay - 1).size() - 2).getY() > heightStart + height))
			widthStart = 60;
		else {
			return;
		}
		int width = 61;
		JPanel eventPanel = new JPanel();
		eventPanel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		eventPanel.setBackground(new Color(152, 251, 152));
		eventPanel.setBounds(widthStart, heightStart, width, height);
		JLabel name = new JLabel(event.getTitle());
		eventPanel.add(name);
		eventPanel.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				showEvent(event);
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		days.get(weekDay - 1).add(eventPanel);
		eventPanels.get(weekDay - 1).add(eventPanel);
	}
	
	public void showEvent(Event event) {
		boolean meeting = false;
		if (event instanceof Meeting)
			meeting = true;
		kjetil.ShowEvent showEvent;
		if (meeting)
			showEvent = new kjetil.ShowEvent((Meeting) event);
		else
			showEvent = new kjetil.ShowEvent((Appointment) event);
		JFrame showEventFrame = new JFrame();
		showEventFrame.setBounds(0, 0, 1000, 1000);
		showEventFrame.setLocationRelativeTo(null);
		showEventFrame.add(showEvent);
		showEventFrame.setVisible(true);
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ArrayList<Event> eventList = new ArrayList<Event>();
					eventList.add(new Appointment(0, "13-03-2014", "1215", 165, "Meeting", "Important meeting", "Dentist", -1));
					eventList.add(new Meeting(1, "13-03-2014", "1415", 105, "Meeting 2", "Unimportant meeting", "Oslo", new ArrayList<Person>(), -1));
					eventList.add(new Appointment(2, "13-03-2014", "1300", 60, "Meeting 3", "Nothing", "P15", -1));
					eventList.add(new Meeting(3, "13-03-2014", "1430", 180, "Meeting 4", "Everything", "Bergen", new ArrayList<Person>(), -1));
					eventList.add(new Appointment(4, "14-03-2014", "0900", 240, "Meeting 5", "42", "Trondheim", -1));
					eventList.add(new Meeting(5, "14-03-2014", "2300", 120, "Meeting 6", "Midnight meeting", "F1", new ArrayList<Person>(), -1));
					//MainFrame frame = new MainFrame(new Calendar(eventList));
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame(Person person) {
		Calendar calendar = new Calendar(DBConnect.getAllEventsOnUser(person.getEmail()));
		ArrayList<Room> rooms = new ArrayList<Room>(DBConnect.getAllRooms());
		for (int i = 0; i < rooms.size(); i++) {
			rooms.get(i).setCalendar(new Calendar(DBConnect.getAllEventsOnRoom(rooms.get(i).getName())));
		}
		dateLabels = new ArrayList<JLabel>();
		cal = java.util.Calendar.getInstance();
		weekNumber = cal.get(java.util.Calendar.WEEK_OF_YEAR);
		events = calendar.getEventList();
		topHour = 8;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1024, 800);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(170, 120, 840, 600);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		mondayPanel = new JPanel();
		mondayPanel.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		mondayPanel.setBackground(Color.WHITE);
		mondayPanel.setBounds(0, 40, 120, 560);
		panel.add(mondayPanel);
		mondayPanel.setLayout(null);
				
		tuesdayPanel = new JPanel();
		tuesdayPanel.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		tuesdayPanel.setBackground(Color.WHITE);
		tuesdayPanel.setBounds(120, 40, 120, 560);
		panel.add(tuesdayPanel);
		tuesdayPanel.setLayout(null);
		
		wednesdayPanel = new JPanel();
		wednesdayPanel.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		wednesdayPanel.setBackground(Color.WHITE);
		wednesdayPanel.setBounds(240, 40, 120, 560);
		panel.add(wednesdayPanel);
		wednesdayPanel.setLayout(null);
		
		thursdayPanel = new JPanel();
		thursdayPanel.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		thursdayPanel.setBackground(Color.WHITE);
		thursdayPanel.setBounds(360, 40, 120, 560);
		panel.add(thursdayPanel);
		thursdayPanel.setLayout(null);
		
		fridayPanel = new JPanel();
		fridayPanel.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		fridayPanel.setBackground(Color.WHITE);
		fridayPanel.setBounds(480, 40, 120, 560);
		panel.add(fridayPanel);
		fridayPanel.setLayout(null);
		
		saturdayPanel = new JPanel();
		saturdayPanel.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		saturdayPanel.setBackground(Color.WHITE);
		saturdayPanel.setBounds(600, 40, 120, 560);
		panel.add(saturdayPanel);
		saturdayPanel.setLayout(null);
		
		sundayPanel = new JPanel();
		sundayPanel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		sundayPanel.setBackground(Color.WHITE);
		sundayPanel.setBounds(720, 40, 120, 560);
		panel.add(sundayPanel);
		sundayPanel.setLayout(null);
		
		JPanel mondayBar = new JPanel();
		mondayBar.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		mondayBar.setBackground(Color.WHITE);
		mondayBar.setBounds(0, 0, 120, 40);
		panel.add(mondayBar);
		mondayBar.setLayout(null);
		
		JLabel lblMonday = new JLabel("Monday");
		lblMonday.setBounds(35, 6, 50, 17);
		lblMonday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		mondayBar.add(lblMonday);
		
		JLabel lblMondayDate = new JLabel();
		lblMondayDate.setBounds(28, 26, 64, 17);
		lblMonday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		mondayBar.add(lblMondayDate);
		dateLabels.add(lblMondayDate);
		
		JPanel tuesdayBar = new JPanel();
		tuesdayBar.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		tuesdayBar.setBackground(Color.WHITE);
		tuesdayBar.setBounds(120, 0, 120, 40);
		panel.add(tuesdayBar);
		tuesdayBar.setLayout(null);
		
		JLabel lblTuesday = new JLabel("Tuesday");
		lblTuesday.setBounds(34, 6, 52, 17);
		lblTuesday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		tuesdayBar.add(lblTuesday);
		
		JLabel lblTuesdayDate = new JLabel();
		lblTuesdayDate.setBounds(28, 26, 64, 17);
		lblTuesday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		tuesdayBar.add(lblTuesdayDate);
		dateLabels.add(lblTuesdayDate);
		
		JPanel wednesdayBar = new JPanel();
		wednesdayBar.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		wednesdayBar.setBackground(Color.WHITE);
		wednesdayBar.setBounds(240, 0, 120, 40);
		panel.add(wednesdayBar);
		wednesdayBar.setLayout(null);
		
		JLabel lblWednesday = new JLabel("Wednesday");
		lblWednesday.setBounds(25, 6, 71, 17);
		lblWednesday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		wednesdayBar.add(lblWednesday);
		
		JLabel lblWednesdayDate = new JLabel();
		lblWednesdayDate.setBounds(28, 26, 64, 17);
		lblWednesday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		wednesdayBar.add(lblWednesdayDate);
		dateLabels.add(lblWednesdayDate);
		
		JPanel thursdayBar = new JPanel();
		thursdayBar.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		thursdayBar.setBackground(Color.WHITE);
		thursdayBar.setBounds(360, 0, 120, 40);
		panel.add(thursdayBar);
		thursdayBar.setLayout(null);
		
		JLabel lblThursday = new JLabel("Thursday");
		lblThursday.setBounds(31, 6, 58, 17);
		lblThursday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		thursdayBar.add(lblThursday);
		
		JLabel lblThursdayDate = new JLabel();
		lblThursdayDate.setBounds(28, 26, 64, 17);
		lblThursday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		thursdayBar.add(lblThursdayDate);
		dateLabels.add(lblThursdayDate);
		
		JPanel fridayBar = new JPanel();
		fridayBar.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		fridayBar.setBackground(Color.WHITE);
		fridayBar.setBounds(480, 0, 120, 40);
		panel.add(fridayBar);
		fridayBar.setLayout(null);
		
		JLabel lblFriday = new JLabel("Friday");
		lblFriday.setBounds(41, 6, 38, 17);
		lblFriday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		fridayBar.add(lblFriday);
		
		JLabel lblFridayDate = new JLabel();
		lblFridayDate.setBounds(28, 26, 64, 17);
		lblFriday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		fridayBar.add(lblFridayDate);
		dateLabels.add(lblFridayDate);
		
		JPanel saturdayBar = new JPanel();
		saturdayBar.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		saturdayBar.setBackground(Color.WHITE);
		saturdayBar.setBounds(600, 0, 120, 40);
		panel.add(saturdayBar);
		saturdayBar.setLayout(null);
		
		JLabel lblSaturday = new JLabel("Saturday");
		lblSaturday.setBounds(33, 6, 55, 17);
		lblSaturday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		saturdayBar.add(lblSaturday);
		
		JLabel lblSaturdayDate = new JLabel();
		lblSaturdayDate.setBounds(28, 26, 64, 17);
		lblSaturday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		saturdayBar.add(lblSaturdayDate);
		dateLabels.add(lblSaturdayDate);
		
		JPanel sundayBar = new JPanel();
		sundayBar.setBorder(new MatteBorder(1, 1, 0, 1, (Color) new Color(0, 0, 0)));
		sundayBar.setBackground(Color.WHITE);
		sundayBar.setBounds(720, 0, 120, 40);
		panel.add(sundayBar);
		sundayBar.setLayout(null);
		
		JLabel lblSunday = new JLabel("Sunday");
		lblSunday.setBounds(37, 6, 46, 17);
		lblSunday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		sundayBar.add(lblSunday);
		
		JLabel lblSundayDate = new JLabel();
		lblSundayDate.setBounds(28, 26, 64, 17);
		lblSunday.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
		sundayBar.add(lblSundayDate);
		dateLabels.add(lblSundayDate);
		
		JPanel datePanel = new JPanel();
		datePanel.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		datePanel.setBackground(Color.LIGHT_GRAY);
		datePanel.setBounds(124, 120, 46, 600);
		getContentPane().add(datePanel);
		datePanel.setLayout(null);
		
		JButton upButton = new JButton("^");
		upButton.setBounds(0, 0, 46, 22);
		datePanel.add(upButton);
		upButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				decrementTopHour();
			}
		});
		
		JButton downButton = new JButton("v");
		downButton.setBounds(0, 578, 46, 22);
		datePanel.add(downButton);
		downButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				incrementTopHour();
			}
		});
		
		hourLabels = new ArrayList<JLabel>();
		for (int i = 0; i < 8; i++) {
			String zero = "";
			if (topHour + i < 10)
				zero = "0";
			JLabel newLabel = new JLabel(zero + (topHour + i) + ":00");
			newLabel.setBounds(10, 25+70*i, 50, 50);
			hourLabels.add(newLabel);
			datePanel.add(newLabel);
		}
		
		JButton btnOtherCalendars = new JButton("Other calendars");
		btnOtherCalendars.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
		btnOtherCalendars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnOtherCalendars.setBounds(124, 63, 135, 29);
		getContentPane().add(btnOtherCalendars);
		
		JButton btnNotification = new JButton("Notifications");
		btnNotification.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
		btnNotification.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNotification.setBounds(893, 63, 117, 29);
		getContentPane().add(btnNotification);
		
		JButton btnAddEvent = new JButton("Add Event");
		btnAddEvent.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
		btnAddEvent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnAddEvent.setBounds(778, 63, 117, 29);
		getContentPane().add(btnAddEvent);
		
		
		JLabel lblWeek = new JLabel("WEEK");
		lblWeek.setFont(new Font("Helvetica Neue", Font.BOLD, 22));
		lblWeek.setBounds(452, 60, 77, 24);
		getContentPane().add(lblWeek);
		
		weeknr = new JLabel(Integer.toString(weekNumber));
		weeknr.setFont(new Font("Helvetica Neue", Font.BOLD, 22));
		weeknr.setBounds(531, 58, 30, 29);
		getContentPane().add(weeknr);
		
		JButton rightButton = new JButton(">>");
		rightButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nextWeek();
			}
		});
		rightButton.setBounds(567, 63, 30, 17);
		getContentPane().add(rightButton);
		
		JButton leftButton = new JButton("<<");
		leftButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				previousWeek();
			}
		});
		leftButton.setBounds(410, 63, 30, 17);
		contentPane.add(leftButton);
		
		days = new ArrayList<JPanel>();
		days.add(sundayPanel);
		days.add(mondayPanel);
		days.add(tuesdayPanel);
		days.add(wednesdayPanel);
		days.add(thursdayPanel);
		days.add(fridayPanel);
		days.add(saturdayPanel);
		
		addAllEvents();
		paintDates();
	}
}
