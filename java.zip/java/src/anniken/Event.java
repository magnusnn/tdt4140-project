package anniken;

import java.text.SimpleDateFormat;
import java.util.Date;


public class Event implements Comparable<Event>{
	private int id;
	private String date;
	private String startTime;
	private int duration;
	private String title;
	private String description;
	private int reminder;
	
	
	//SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	//SimpleDateFormat timeFormat = new SimpleDateFormat("HHmm");
	
	public Event(int id, String date, String startTime, int duration, String title, String description, int reminder){
		this.id = id;
		this.date = date;
		this.startTime = startTime;
		this.duration = duration;
		this.title = title;
		this.description = description;
		this.reminder = reminder;
	}
	
	public int getID(){
		return this.id;
	}
	public void setID(int id){
		this.id = id;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getTitle(){
		return title;
	}
	public void setTitle(String title){
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getReminder(){
		return reminder;
	}
	public void setReminder(int r){
		this.reminder = r;
	}

	@Override
	public int compareTo(Event other) {
		try {
			Date time = new SimpleDateFormat("dd-MM-yyyy HHmm").parse(getDate() + " " + getStartTime());
			Date otherTime = new SimpleDateFormat("dd-MM-yyyy HHmm").parse(other.getDate() + " " + other.getStartTime());
			return time.compareTo(otherTime);
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			return 0;
		}
	}
}
