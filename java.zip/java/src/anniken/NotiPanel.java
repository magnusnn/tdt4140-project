package anniken;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

public class NotiPanel extends JPanel {
	private ArrayList<per.Notification> notiList;
	private Event event = new Event(1,"13-03-2104", "1000", 45, "M�te", "Evaluering av prosjekt",5);
	private Event event2 = new Event(2, "13-03-2104", "1000", 45, "Anna m�te", "Hei",5);
	private Event event3 = new Event(3,"13-03-2104", "1000", 45, "test3", "warrup",5);
	private Event event4 = new Event(4,"13-03-2104", "1000", 45, "jei", "Hei", 5);
	private Event event5 = new Event(5,"13-03-2104", "1000", 45, "m�te", "statoil", 5);
	private Event event6 = new Event(6,"13-03-2104", "1000", 45, "Anna m�te", "heisann",5);
	public ArrayList<Event> eventList = new ArrayList();
	private Person person = new Person("hei", "tora", "berger", "20-03-2014");
	
	public NotiPanel(){
		//Add notifications to alist
		this.notiList = new ArrayList();
		
		this.notiList.add(new per.Notification("tekst", event, person, 1));
		this.notiList.add(new per.Notification("tekst", event2, person, 2));
		this.notiList.add(new per.Notification("tekst", event3, person, 3));
		this.notiList.add(new per.Notification("tekst", event4, person, 4));
		this.notiList.add(new per.Notification("tekst", event5, person, 5));
		this.notiList.add(new per.Notification("tekst", event6, person, 6));
		this.notiList.add(new per.Notification("text", new Event(7,"12-03-2031","1000",45,"heimlte","heruru",5),person, 7));
		
		//Setup backpanel
		setLayout(null);
		setSize(400,400);
		
		//JPanel som inneholder miniNotiPanels
		JPanel backPanel = new JPanel();
		backPanel.setSize(250, 1000);
		GridLayout g = new GridLayout(0,1);
		backPanel.setLayout(g);
		add(backPanel);
		
	
		//Lage miniPanels
		int counter = 0;
		for(per.Notification n:notiList){
			JPanel miniPanel = new JPanel();
			miniPanel.setLayout(null);
			miniPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
			miniPanel.setBackground(Color.WHITE);
			miniPanel.setBounds(0, 60*counter, 220, 60);
			miniPanel.setPreferredSize(new Dimension(220,60));
			
			JLabel lblTitle = new JLabel("Title");
			lblTitle.setFont(new Font("Lucida Grande", Font.BOLD, 13));
			lblTitle.setBounds(6, 6, 200, 16);
			lblTitle.setText(n.getEvent().getTitle());	
			miniPanel.add(lblTitle);
			
			JLabel lblDescription = new JLabel("Descrp");
			lblDescription.setBounds(6, 34, 200, 16);
			lblDescription.setText(n.getEvent().getDescription());
			miniPanel.add(lblDescription);
			
			//legge til backpanel
			backPanel.add(miniPanel);
			counter++;
			System.out.println(counter);
		}
		
		//Legge til JScrollPane
		JScrollPane scroll = new JScrollPane();
		scroll.setViewportView(backPanel);
		scroll.setBounds(20, 20, 250, 300);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		add(scroll);
		//revalidate();
		repaint();
	}
	

}
