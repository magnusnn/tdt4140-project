package anniken;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import javax.swing.JButton;
import java.awt.Button;
import java.awt.image.BufferedImage;

public class Main extends JPanel {

	/**
	 * Create the panel.
	 */
	public Main() {
		setBorder(new LineBorder(new Color(0, 0, 0)));
		setBackground(Color.WHITE);
		this.setBounds(0, 0, 1024, 800);
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(170, 120, 840, 600);
		add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 40, 120, 560);
		panel.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(120, 40, 120, 560);
		panel.add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		panel_3.setBackground(Color.WHITE);
		panel_3.setBounds(240, 40, 120, 560);
		panel.add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		panel_4.setBackground(Color.WHITE);
		panel_4.setBounds(360, 40, 120, 560);
		panel.add(panel_4);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		panel_5.setBackground(Color.WHITE);
		panel_5.setBounds(480, 40, 120, 560);
		panel.add(panel_5);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		panel_6.setBackground(Color.WHITE);
		panel_6.setBounds(600, 40, 120, 560);
		panel.add(panel_6);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel_7.setBackground(Color.WHITE);
		panel_7.setBounds(720, 40, 120, 560);
		panel.add(panel_7);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		panel_9.setBackground(Color.WHITE);
		panel_9.setBounds(0, 0, 120, 40);
		panel.add(panel_9);
		
		JLabel lblMandag = new JLabel("Mandag");
		panel_9.add(lblMandag);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		panel_10.setBackground(Color.WHITE);
		panel_10.setBounds(120, 0, 120, 40);
		panel.add(panel_10);
		
		JLabel lblTirsdag = new JLabel("Tirsdag");
		panel_10.add(lblTirsdag);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		panel_11.setBackground(Color.WHITE);
		panel_11.setBounds(240, 0, 120, 40);
		panel.add(panel_11);
		
		JLabel lblOnsdag = new JLabel("Onsdag");
		panel_11.add(lblOnsdag);
		
		JPanel panel_12 = new JPanel();
		panel_12.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		panel_12.setBackground(Color.WHITE);
		panel_12.setBounds(360, 0, 120, 40);
		panel.add(panel_12);
		
		JLabel lblTorsdag = new JLabel("Torsdag");
		panel_12.add(lblTorsdag);
		
		JPanel panel_13 = new JPanel();
		panel_13.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		panel_13.setBackground(Color.WHITE);
		panel_13.setBounds(480, 0, 120, 40);
		panel.add(panel_13);
		
		JLabel lblFredag = new JLabel("Fredag");
		panel_13.add(lblFredag);
		
		JPanel panel_14 = new JPanel();
		panel_14.setBorder(new MatteBorder(1, 1, 0, 0, (Color) new Color(0, 0, 0)));
		panel_14.setBackground(Color.WHITE);
		panel_14.setBounds(600, 0, 120, 40);
		panel.add(panel_14);
		
		JLabel lblLrdag = new JLabel("L\u00F8rdag");
		panel_14.add(lblLrdag);
		
		JPanel panel_15 = new JPanel();
		panel_15.setBorder(new MatteBorder(1, 1, 0, 1, (Color) new Color(0, 0, 0)));
		panel_15.setBackground(Color.WHITE);
		panel_15.setBounds(720, 0, 120, 40);
		panel.add(panel_15);
		
		JLabel lblSndag = new JLabel("S\u00F8ndag");
		panel_15.add(lblSndag);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBorder(new MatteBorder(1, 1, 1, 0, (Color) new Color(0, 0, 0)));
		panel_8.setBackground(Color.LIGHT_GRAY);
		panel_8.setBounds(124, 120, 46, 600);
		add(panel_8);

		
	}
}
