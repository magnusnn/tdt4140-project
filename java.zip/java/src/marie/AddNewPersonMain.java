package marie;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class AddNewPersonMain extends JFrame{
	static JFrame frame;
	private JPanel panel; 
	


	public static void main(String[] args){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new AddNewPersonMain();
					frame.setVisible(true);
					frame.add(new ParticipantSelector());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}