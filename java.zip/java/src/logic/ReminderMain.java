package logic;

import gui.FireReminder;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ReminderMain { 
  
	public static void main(final ArrayList<Reminder> reminders) {
		
		for (int i = 0; i < reminders.size(); i++) {
			final Reminder reminder = reminders.get(i);
			
			Date eventDate = new Date(0);
			try {
				eventDate = new SimpleDateFormat("dd-MM-yyyy HHmm").parse(reminder.getEvent().getDate() + " " + reminder.getEvent().getStartTime());
			}
			catch (Exception e) {
			}
			
			Date reminderDate = new Date(eventDate.getTime() - 60000 * reminder.getReminder());
			java.util.Calendar c = java.util.Calendar.getInstance();
			Date nowDate = new Date(c.getTimeInMillis());
			int seconds = (int) (reminderDate.getTime() - nowDate.getTime()) / 1000;
			if (seconds < 0)
				continue;
			
			System.out.println("eventDate: " + eventDate);
			System.out.println("reminderDate: " + reminderDate);
			System.out.println("nowDate: " + nowDate);
			System.out.println("seconds: " + seconds);
		
			final ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
			service.scheduleWithFixedDelay(new Runnable() {
        
				@Override
				public void run() {
					new FireReminder(reminder);
				}
			}, 0, seconds, TimeUnit.SECONDS);
		}
	}
}