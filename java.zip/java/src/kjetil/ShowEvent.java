package kjetil;

import java.awt.Color;

import javax.swing.DefaultListModel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JList;

public class ShowEvent extends JPanel {
	private anniken.Appointment appointment;
	private anniken.Meeting meeting;
	
	private DefaultListModel listModel;
	/**
	 *
	 */
	public ShowEvent(anniken.Appointment a) {
		this.appointment = a;
		
		
		setLayout(null);
		showAppointment();
//		showMeeting();
		
	}
	
	public ShowEvent(anniken.Meeting m){
		this.meeting = m;
		setLayout(null);
		showMeeting();
	}
	
	public void showMeeting(){
		
		setBounds(0,0,500,250);
		
		JLabel lblNewLabel = new JLabel("Description");
		lblNewLabel.setBounds(19, 56, 73, 16);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Date");
		lblNewLabel_1.setBounds(19, 116, 61, 16);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Time");
		lblNewLabel_2.setBounds(19, 146, 61, 16);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Place");
		lblNewLabel_3.setBounds(19, 176, 61, 16);
		add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Reminder");
		lblNewLabel_4.setBounds(19, 206, 61, 16);
		add(lblNewLabel_4);
		
		JLabel lblTitle = new JLabel("Title");
		lblTitle.setBounds(19, 25, 61, 16);
		lblTitle.setFont (lblTitle.getFont ().deriveFont (16.0f));
		//lblTitle.setForeground(Color.GRAY);
		add(lblTitle);
		
		JLabel description = new JLabel(meeting.getDescription());
		description.setBounds(123, 56, 220, 60);
		description.setForeground(Color.GRAY);
		add(description);
		
		JLabel date = new JLabel(meeting.getDate());
		date.setBounds(123, 116, 61, 16);
		date.setForeground(Color.GRAY);
		add(date);
		
		JLabel time = new JLabel(meeting.getStartTime());
		time.setBounds(123, 146, 61, 16);
		time.setForeground(Color.GRAY);
		add(time);
		
		JLabel place = new JLabel("FIX");
		place.setBounds(123, 176, 61, 16);
		place.setForeground(Color.GRAY);
		add(place);
		
		JLabel reminder = new JLabel("");
		reminder.setBounds(123, 206, 61, 16);
		reminder.setForeground(Color.GRAY);
		add(reminder);
		
		listModel = new DefaultListModel();
		for (int i = 0; i<meeting.getPersonList().size(); i++){
			listModel.addElement(meeting.getPersonList().get(i).getGivenName() + " " + meeting.getPersonList().get(i).getSurname());
		}
		JList list = new JList(listModel);
		list.setBounds(355, 57, 127, 122);
		add(list);
		
		JLabel lblRoom = new JLabel("Room");
		lblRoom.setBounds(305, 206, 61, 16);
		add(lblRoom);
		
		JLabel room = new JLabel(meeting.getPlace()); //Should be getRoom.
		room.setBounds(355, 206, 61, 16);
		add(room);
		
		if(meeting.getReminder() == -1){
			reminder.setText("No reminder");
		}
		else{
			reminder.setText("" + meeting.getReminder());
		}
	}
	public void showAppointment(){
		
		setBounds(0,0,375,250);
		
		JLabel lblNewLabel = new JLabel("Description");
		lblNewLabel.setBounds(19, 56, 73, 16);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Date");
		lblNewLabel_1.setBounds(19, 116, 61, 16);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Time");
		lblNewLabel_2.setBounds(19, 146, 61, 16);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Place");
		lblNewLabel_3.setBounds(19, 176, 61, 16);
		add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Reminder");
		lblNewLabel_4.setBounds(19, 206, 61, 16);
		add(lblNewLabel_4);
		
		JLabel lblTitle = new JLabel("Title");
		lblTitle.setBounds(19, 25, 61, 16);
		lblTitle.setFont (lblTitle.getFont ().deriveFont (16.0f));
		//lblTitle.setForeground(Color.GRAY);
		add(lblTitle);
		
		JLabel description = new JLabel(appointment.getDescription());
		description.setBounds(123, 56, 220, 50);
		description.setForeground(Color.GRAY);
		add(description);
		
		JLabel date = new JLabel(appointment.getDate());
		date.setBounds(123, 116, 61, 16);
		date.setForeground(Color.GRAY);
		add(date);
		
		JLabel time = new JLabel(appointment.getStartTime());
		time.setBounds(123, 146, 61, 16);
		time.setForeground(Color.GRAY);
		add(time);
		
		JLabel place = new JLabel(appointment.getPlace());
		place.setBounds(123, 176, 61, 16);
		place.setForeground(Color.GRAY);
		add(place);
		
		JLabel reminder = new JLabel("");
		reminder.setBounds(123, 206, 61, 16);
		reminder.setForeground(Color.GRAY);
		add(reminder);
		
		if(appointment.getReminder() == -1){
			reminder.setText("No reminder");
		}
		else{
			reminder.setText("" + appointment.getReminder());
		}
	}
}
