package per;

public class Util {
	
	public boolean valiDate(String date) {
		int day = Integer.parseInt(date.substring(0, 2));
		int month = Integer.parseInt(date.substring(3, 5));
		int year = Integer.parseInt(date.substring(6));
		if (day > 31 || day < 1)
			return false;
		if (month > 12 || month < 1)
			return false;
		if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30)
			return false;
		if (month == 2 && day > 29)
			return false;
		if (month == 2 && (year % 4 != 0 || (year % 100 == 0 && year % 400 != 0)) && day > 28)
			return false;
		return true;
	}
}