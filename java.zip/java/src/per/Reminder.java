package per;

import java.util.Date;
import anniken.Event;

public class Reminder {

	private Date startTime;
	private Event event;
	
	public Reminder(Date startTime, Event event) {
		setStartTime(startTime);
		setEvent(event);
	}
	
	public void setStartTime(Date startTime) {
			this.startTime = startTime;
	}
	
	public void setEvent(Event event) {
		this.event = event;
	}
	
	public Date getStartTime() {
		return startTime;
	}
	
	public Event getEvent() {
		return event;
	}
	
	public void fire() {
		//add a new reminder frame
	}
}